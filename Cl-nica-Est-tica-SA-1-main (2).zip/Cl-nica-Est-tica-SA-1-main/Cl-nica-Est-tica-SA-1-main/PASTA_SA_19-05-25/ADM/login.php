<?php
require_once 'conexao.php';
$conn = conectarBanco();

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    if ($email && $senha) {
        $stmt = $conn->prepare("SELECT * FROM login WHERE email = ? AND senha = ?");
        $stmt->execute([$email, $senha]);
        $usuario = $stmt->fetch();

        if ($usuario) {
            $_SESSION['usuario'] = $usuario;
            header("Location: principal.php");
            exit();
        } else {
            $erro = "Usuário ou senha inválidos.";
        }
    } else {
        $erro = "Preencha todos os campos.";
    }
}
?>


<!-- HTML simplificado de login -->
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body class="cadastro-fundo">
    <div class="formulario">
        <form method="POST">
            <fieldset>
                <legend>Login</legend>
                <label for="email">Email:</label>
                <input type="email" name="email" required>

                <label for="senha">Senha:</label>
                <input type="password" name="senha" required>

                <div class="botoes">
                    <button class="botao_cadastro" type="submit">Entrar</button>
                </div>
            </fieldset>
            <?php if (isset($erro)) echo "<p style='color:red;'>$erro</p>"; ?>
        </form>
    </div>
</body>
</html>