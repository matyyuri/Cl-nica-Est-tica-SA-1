<?php
try {
    $con = new PDO("mysql:host=localhost;port=3307;dbname=clinica;charset=utf8", "root", "root");
    echo "Conexão bem-sucedida!";
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>