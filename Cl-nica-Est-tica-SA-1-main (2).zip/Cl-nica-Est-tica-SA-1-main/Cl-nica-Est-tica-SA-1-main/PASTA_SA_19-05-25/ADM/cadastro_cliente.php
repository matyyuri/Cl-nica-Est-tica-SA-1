<?php
require_once 'conexao.php';
$conn = conectarBanco();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    if ($email && $senha) {
        $stmt = $conn->prepare("INSERT INTO login (email, senha) VALUES (?, ?)");
        if ($stmt->execute([$email, $senha])) {
            echo "<script>alert('Usuário cadastrado com sucesso!'); window.location='login.php';</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar. Verifique se o email já está em uso.');</script>";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body class="cadastro-fundo">
    <div class="formulario">
        <form method="POST">
            <fieldset>
                <legend>Cadastro de Usuário</legend>

                <label for="email">Email:</label>
                <input type="email" name="email" required>

                <label for="senha">Senha:</label>
                <input type="password" name="senha" required>

                <div class="botoes">
                    <button class="botao_cadastro" type="submit">Cadastrar</button>
                    <button class="botao_limpeza" type="reset">Limpar</button>
                </div>
            </fieldset>
        </form>
    </div>
</body>
</html>
