<?php
require_once 'conexao.php';

$result = $conn->query("SELECT * FROM login");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Usuários</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h2 class="h2info">Lista de Usuários</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Senha</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row['id_login'] ?></td>
                    <td><?= $row['email'] ?></td>
                    <td><?= $row['senha'] ?></td>
                    <td>
                        <a href="alterar_usuario.php?id_login=<?= $row['id_login'] ?>">Editar</a> |
                        <a href="excluir_usuario.php?id=<?= $row['id_login'] ?>" onclick="return confirm('Tem certeza?')">Excluir</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>