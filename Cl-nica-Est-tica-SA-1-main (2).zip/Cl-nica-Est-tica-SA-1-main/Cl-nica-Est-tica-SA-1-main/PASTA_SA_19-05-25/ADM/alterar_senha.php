<?php
require_once 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    if ($email && $senha) {
        $stmt = $conn->prepare("UPDATE login SET senha = ? WHERE email = ?");
        $stmt->bind_param("ss", $senha, $email);

        if ($stmt->execute()) {
            echo "<script>alert('Senha alterada com sucesso!'); window.location='login.php';</script>";
        } else {
            echo "<script>alert('Erro ao alterar a senha.');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Alterar Senha</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body class="cadastro-fundo">
    <div class="formulario">
        <form method="POST">
            <fieldset>
                <legend>Alterar Senha</legend>

                <label for="email">Email:</label>
                <input type="email" name="email" required>

                <label for="senha">Nova Senha:</label>
                <input type="password" name="senha" required>

                <div class="botoes">
                    <button class="botao_cadastro" type="submit">Alterar</button>
                </div>
            </fieldset>
        </form>
    </div>
</body>
</html>